# dsh-raganything-kb 0.3.13-sharedkb

分支：8.6 多用户网关线（sharedkb），基线 = 0.3.12-sharedkb。
与基线唯一的代码差异：修复「@ 共享文件 / 文件夹 限定范围问答返回『没有检索到』」。

## 根因（两层）

| 层 | 问题 |
| --- | --- |
| ① 前缀不对称 | 共享 chunk 的 `file_path` 带 `共享/` 前缀，前端 `@` scope 不带；旧 `_in_scope` 只剥 `全部文档/` |
| ② 作用域检索跑在用户实例本地（系统性主因） | 用户实例 `rag` 只持私有库（0 个 `共享/` chunk），共享库本体在宿主 sidecar（17321）；`@` 限定范围被路由到用户实例本地跑，永远查不到共享库 |

全库检索（不加 @）正常，是因为它走 `rag.aquery`（宿主可达）——唯独 `@` 范围被留在本地。

## 修复

- 修复①：`_VROOT_PREFIXES` 加 `"共享/"`，`_in_scope` 对 chunk 与 scope 两端对称剥虚拟根。
- 修复②（host-aware）：`_route_scope_query` 在**宿主实例**（`_shared_is_local()` 为 True）直接本地检索；
  **用户实例**把命中共享文件夹的作用域转发宿主 sidecar（`SHARED_BASE`/17321）检索，私有部分仍本地检索并合并
  （带【共享知识库】/【私有知识库】标签）。单文件同时正确服务宿主与用户实例，不会转发自环。

## 验证（线上）

8.6 多用户网关 admin 实例 `@ 01-算力一部/灵拓·Tokens Store Token聚合服务平台0819.pptx`
由 hits=0 变为 **hits=18**，回答正常，不再出现「没有检索到与该问题相关的内容」。

## 其他

- 0.3.12 的 artcontent 修复（`GET /documents/{art-*}/content` 不再 404）原样保留。
- 部署注意：8.6 上 12 份 profile 的依赖仍写着
  `file:/home/lgsj/dsh-raganything-kb-0.3.12-sharedkb.tgz`，换用本包需同步改依赖并重启
  （宿主 `systemctl restart raganything-sidecar`；用户实例 `POST :3200N/models/restart`）。
