# dsh-raganything-kb 0.3.12-sharedkb

分支：8.6 多用户网关线（sharedkb），基线 = 0.3.11-sharedkb。
与基线唯一的代码差异：`/documents/{doc_id}/content` 增加 `art-` 前缀分支。

## 修复内容

「只落盘不入库」的对话产物（doc_id = `art-<uuid>-<name>`）：

| 端点 | 0.3.11 | 0.3.12 |
| --- | --- | --- |
| `GET /documents/{art-*}/file` | 200（已支持） | 200 |
| `GET /documents/{art-*}/content` | **404** | **200** |

0.3.11 里 `document_content` 只查 LightRAG `full_docs`，对 `art-` 恒 404，
前端 `ragDocContent` 拿到 null 就弹「无法读取原始文件内容：RAG-Anything 无响应或该文档无内容」。
文本型产物（.md）走 `document_file` 仍能打开，所以故障只体现在 Word/Excel/PPT 类
office 产物上。

0.3.12 行为：文本型返回正文；二进制型（docx/xlsx/pptx/pdf/图片/压缩包等）返回
空 `content` + `file_path`，由前端经 `ofvUrl` 交给 Open File Viewer 渲染。

## 其他

- 移除 0.3.11 包内误带的 `sidecar/server.py.scopefix-20260915-121321.bak`。
- 部署注意：8.6 上 12 份 profile 的依赖仍写着
  `file:/home/lgsj/dsh-raganything-kb-0.3.11-sharedkb.tgz`，换用本包需同步改依赖并重启。
